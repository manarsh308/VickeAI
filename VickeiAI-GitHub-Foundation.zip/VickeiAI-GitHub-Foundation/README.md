# VickeiAI

Foundation repository.
