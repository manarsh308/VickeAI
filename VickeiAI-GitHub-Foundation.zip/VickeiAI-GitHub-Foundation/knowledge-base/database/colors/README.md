# colors

Purpose: knowledge-base/database/colors
