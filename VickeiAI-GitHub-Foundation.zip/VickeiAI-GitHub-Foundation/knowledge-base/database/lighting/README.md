# lighting

Purpose: knowledge-base/database/lighting
