# metadata

Purpose: knowledge-base/database/metadata
