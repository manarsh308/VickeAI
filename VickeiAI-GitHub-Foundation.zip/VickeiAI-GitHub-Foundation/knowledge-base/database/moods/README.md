# moods

Purpose: knowledge-base/database/moods
