# negative-prompts

Purpose: knowledge-base/database/negative-prompts
