# styles

Purpose: knowledge-base/database/styles
