# textures

Purpose: knowledge-base/database/textures
