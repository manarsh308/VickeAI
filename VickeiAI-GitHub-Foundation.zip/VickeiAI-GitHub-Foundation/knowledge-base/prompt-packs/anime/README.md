# anime

Purpose: knowledge-base/prompt-packs/anime
