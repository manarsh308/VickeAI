# cinematic

Purpose: knowledge-base/prompt-packs/cinematic
