# devotional

Purpose: knowledge-base/prompt-packs/devotional
