# fantasy

Purpose: knowledge-base/prompt-packs/fantasy
