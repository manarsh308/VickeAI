# realistic

Purpose: knowledge-base/prompt-packs/realistic
