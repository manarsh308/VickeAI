# scifi

Purpose: knowledge-base/prompt-packs/scifi
