# youtube-shorts

Purpose: knowledge-base/prompt-packs/youtube-shorts
